function preload(){
    imagen = loadImage("dog_cat.jpg");
}
function setup(){
    canvas = createCanvas(640, 420);
    canvas.center();
}
function draw(){
    image(imagen, 0, 0, 640, 420);
}